<?php

$mysqli = new mysqli("localhost", "root", "1234", "salon");

?>